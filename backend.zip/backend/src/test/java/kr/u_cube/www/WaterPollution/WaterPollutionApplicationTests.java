package kr.u_cube.www.WaterPollution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterPollutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
